package com.example.copybara;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class kc1_intro extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.kc1_intro);

        Button k20203 = findViewById(R.id.k20203);
        Button k20202 = findViewById(R.id.k20203);
        Button k20201 = findViewById(R.id.k20201);
        Button k20193 = findViewById(R.id.k20193);
        Button k20192 = findViewById(R.id.k20192);
        Button k20191 = findViewById(R.id.k20191);
        Button k20183 = findViewById(R.id.k20183);
        Button k20182 = findViewById(R.id.k20182);
        Button k20181 = findViewById(R.id.k20181);
        Button k20173 = findViewById(R.id.k20173);
        Button k20172 = findViewById(R.id.k20172);
        Button k20171 = findViewById(R.id.k20171);



        k20203.setOnClickListener(view -> {
            Intent intent = new Intent(kc1_intro.this, kc1_intro2.class);
            startActivity(intent);
        });
        k20202.setOnClickListener(view -> {
            Intent intent = new Intent(kc1_intro.this, kc1_intro2.class);
            startActivity(intent);
        });
        k20201.setOnClickListener(view -> {
            Intent intent = new Intent(kc1_intro.this, kc1_intro2.class);
            startActivity(intent);
        });
        k20193.setOnClickListener(view -> {
            Intent intent = new Intent(kc1_intro.this, kc1_intro2.class);
            startActivity(intent);
        });
        k20192.setOnClickListener(view -> {
            Intent intent = new Intent(kc1_intro.this, kc1_intro2.class);
            startActivity(intent);
        });
        k20191.setOnClickListener(view -> {
            Intent intent = new Intent(kc1_intro.this, kc1_intro2.class);
            startActivity(intent);
        });
        k20183.setOnClickListener(view -> {
            Intent intent = new Intent(kc1_intro.this, kc1_intro2.class);
            startActivity(intent);
        });
        k20182.setOnClickListener(view -> {
            Intent intent = new Intent(kc1_intro.this, kc1_intro2.class);
            startActivity(intent);
        });
        k20181.setOnClickListener(view -> {
            Intent intent = new Intent(kc1_intro.this, kc1_intro2.class);
            startActivity(intent);
        });
        k20173.setOnClickListener(view -> {
            Intent intent = new Intent(kc1_intro.this, kc1_intro2.class);
            startActivity(intent);
        });
        k20172.setOnClickListener(view -> {
            Intent intent = new Intent(kc1_intro.this, kc1_intro2.class);
            startActivity(intent);
        });
        k20171.setOnClickListener(view -> {
            Intent intent = new Intent(kc1_intro.this, kc1_intro2.class);
            startActivity(intent);
        });




        findViewById(R.id.backarrow).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }}
