package com.example.copybara;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;

import com.example.copybara.other.Constants;

public class kc1_intro2 extends AppCompatActivity{
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.kc1_intro2);

        ImageButton python_quizstart = findViewById(R.id.quizstart);

        python_quizstart.setOnClickListener(view -> {
            Intent intent = new Intent(kc1_intro2.this, pythonActivity.class);
            intent.putExtra(Constants.SUBJECT,getString(R.string.kichul));
            startActivity(intent);
        });

        findViewById(R.id.backarrow).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }}

