package com.example.copybara;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class kichul_intro extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.kichul_intro);

        Button kc1 = findViewById(R.id.kc1);
        Button kc2 = findViewById(R.id.kc2);
        Button kc3 = findViewById(R.id.kc3);
        Button kc4 = findViewById(R.id.kc4);
        Button kc5 = findViewById(R.id.kc5);
        Button kc6 = findViewById(R.id.kc6);
        Button kc7 = findViewById(R.id.kc7);
        Button kc8 = findViewById(R.id.kc8);
        Button kc9 = findViewById(R.id.kc9);
        Button kc10 = findViewById(R.id.kc10);
        Button kc11 = findViewById(R.id.kc11);
        Button kc12 = findViewById(R.id.kc12);
        Button kc13 = findViewById(R.id.kc13);
        Button kc14 = findViewById(R.id.kc14);



        kc1.setOnClickListener(view -> {
            Intent intent = new Intent(kichul_intro.this, kc1_intro.class);
            startActivity(intent);
        });
        kc2.setOnClickListener(view -> {
            Intent intent = new Intent(kichul_intro.this, kc1_intro.class);
            startActivity(intent);
        });
        kc3.setOnClickListener(view -> {
            Intent intent = new Intent(kichul_intro.this, kc1_intro.class);
            startActivity(intent);
        });
        kc4.setOnClickListener(view -> {
            Intent intent = new Intent(kichul_intro.this, kc1_intro.class);
            startActivity(intent);
        });
        kc5.setOnClickListener(view -> {
            Intent intent = new Intent(kichul_intro.this, kc1_intro.class);
            startActivity(intent);
        });
        kc6.setOnClickListener(view -> {
            Intent intent = new Intent(kichul_intro.this, kc1_intro.class);
            startActivity(intent);
        });
        kc7.setOnClickListener(view -> {
            Intent intent = new Intent(kichul_intro.this, kc1_intro.class);
            startActivity(intent);
        });
        kc8.setOnClickListener(view -> {
            Intent intent = new Intent(kichul_intro.this, kc1_intro.class);
            startActivity(intent);
        });
        kc9.setOnClickListener(view -> {
            Intent intent = new Intent(kichul_intro.this, kc1_intro.class);
            startActivity(intent);
        });
        kc10.setOnClickListener(view -> {
            Intent intent = new Intent(kichul_intro.this, kc1_intro.class);
            startActivity(intent);
        });
        kc11.setOnClickListener(view -> {
            Intent intent = new Intent(kichul_intro.this, kc1_intro.class);
            startActivity(intent);
        });
        kc12.setOnClickListener(view -> {
            Intent intent = new Intent(kichul_intro.this, kc1_intro.class);
            startActivity(intent);
        });
        kc13.setOnClickListener(view -> {
            Intent intent = new Intent(kichul_intro.this, kc1_intro.class);
            startActivity(intent);
        });
        kc14.setOnClickListener(view -> {
            Intent intent = new Intent(kichul_intro.this, kc1_intro.class);
            startActivity(intent);
        });



        findViewById(R.id.backarrow).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }}
