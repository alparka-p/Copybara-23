package com.example.copybara;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.copybara.data.Attempt;
import com.example.copybara.data.UserDatabase;
import com.example.copybara.data.UserDatabaseClient;
import com.example.copybara.other.Constants;
import com.example.copybara.other.SharedPref;
import com.example.copybara.other.Utils;

import java.util.Calendar;

public class FinalResultActivity extends AppCompatActivity {

    private TextView tvSubject, tvCorrect, tvIncorrect, tvDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_final_result);

        Intent intent = getIntent();
        int correctAnswer = intent.getIntExtra(Constants.CORRECT, 0);
        int incorrectAnswer = intent.getIntExtra(Constants.INCORRECT, 0);
        String subject = intent.getStringExtra(Constants.SUBJECT);
        String email = SharedPref.getInstance().getUser(this).getEmail();
        int earnedPoints = (correctAnswer * Constants.CORRECT_POINT) - (incorrectAnswer * Constants.INCORRECT_POINT);

        tvSubject = findViewById(R.id.textView16);
        tvCorrect = findViewById(R.id.textView19);
        tvIncorrect = findViewById(R.id.textView27);
        tvDate = findViewById(R.id.textView30);


        TextView tvTitle = findViewById(R.id.pythontitle);

        if (subject.equals(getString(R.string.python))) {
            tvTitle.setText(getString(R.string.python));

        }  else if (subject.equals(getString(R.string.java))){
            tvTitle.setText(getString(R.string.java));

        } else if (subject.equals(getString(R.string.c1))){
            tvTitle.setText(getString(R.string.c1));

        }  else if (subject.equals(getString(R.string.c2))){
            tvTitle.setText(getString(R.string.c2));

        } else if (subject.equals(getString(R.string.kotlin))){
            tvTitle.setText(getString(R.string.kotlin));

        } else if (subject.equals(getString(R.string.sql))){
            tvTitle.setText(getString(R.string.sql));

        } else if (subject.equals(getString(R.string.php))){
            tvTitle.setText(getString(R.string.php));

        } else if (subject.equals(getString(R.string.r))){
            tvTitle.setText(getString(R.string.r));

        } else if (subject.equals(getString(R.string.js))){
            tvTitle.setText(getString(R.string.js));

        } else if (subject.equals(getString(R.string.css))){
            tvTitle.setText(getString(R.string.css));

        } else if (subject.equals(getString(R.string.html))){
            tvTitle.setText(getString(R.string.html));


        }else {
            tvTitle.setText(getString(R.string.kichul));
        }


        findViewById(R.id.backhome).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(FinalResultActivity.this,MainActivity.class);
                startActivity(intent);
                finish();
            }
        });



        Attempt attempt = new Attempt(
                Calendar.getInstance().getTimeInMillis(),
                subject,
                correctAnswer,
                incorrectAnswer,
                earnedPoints,
                email
        );

        getOverAllPoints(attempt);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent intent = new Intent(this,MainActivity.class);
        startActivity(intent);
        finish();
    }

    private void getOverAllPoints(Attempt attempt) {
        GetOverallPointsTask getOverallPointsTask = new GetOverallPointsTask(attempt);
        getOverallPointsTask.execute();
    }

    class GetOverallPointsTask extends AsyncTask<Void, Void, Void> {

        private final Attempt attempt;
        private int overallPoints = 0;

        public GetOverallPointsTask(Attempt attempt) {
            this.attempt = attempt;
        }

        @Override
        protected Void doInBackground(Void... voids) {
            UserDatabase databaseClient = UserDatabaseClient.getInstance(getApplicationContext());
            overallPoints = databaseClient.userDao().getOverAllPoints(attempt.getEmail());
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);

            attempt.setOverallPoints(overallPoints + attempt.getEarned());
            displayData(attempt);
            SaveUserAttemptTask saveUserAttemptTask = new SaveUserAttemptTask(attempt);
            saveUserAttemptTask.execute();

            Log.d("OVERALL POINTS", String.valueOf(overallPoints));
        }
    }

    private void displayData(Attempt attempt) {

        tvSubject.setText(attempt.getSubject());
        tvCorrect.setText(String.valueOf(attempt.getCorrect()));
        tvIncorrect.setText(String.valueOf(attempt.getIncorrect()));
        tvDate.setText(Utils.formatDate(attempt.getCreatedTime()));

    }

    class SaveUserAttemptTask extends AsyncTask<Void, Void, Void> {

        private Attempt attempt;

        public SaveUserAttemptTask(Attempt attempt) {
            this.attempt = attempt;
        }

        @Override
        protected Void doInBackground(Void... voids) {
            UserDatabase databaseClient = UserDatabaseClient.getInstance(getApplicationContext());
            databaseClient.userDao().insertAttempt(attempt);
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
            Log.d("Attempt Saved", attempt.toString());
        }
    }
}