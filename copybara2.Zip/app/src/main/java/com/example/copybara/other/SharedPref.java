package com.example.copybara.other;

import android.content.Context;
import android.content.SharedPreferences;

import androidx.annotation.NonNull;

import com.example.copybara.ChartFragment;
import com.example.copybara.FinalResultActivity;
import com.example.copybara.InfoFragment;
import com.example.copybara.LoginActivity;
import com.example.copybara.data.User;
import com.google.gson.Gson;

public class SharedPref {

    private static SharedPref instance = null;

    private static final String sharedPreferencesName = "kevinSharedPref";


    private SharedPref() {
    }

    public static SharedPref getInstance() {
        if (instance == null) {
            instance = new SharedPref();
        }
        return instance;
    }

    public void setUser(Context context, User user){
        SharedPreferences pref = context.getSharedPreferences(sharedPreferencesName, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = pref.edit();
        editor.putString(Constants.USER,new Gson().toJson(user));
        editor.apply();
    }

    public User getUser(LoginActivity context){
        SharedPreferences pref = context.getSharedPreferences(sharedPreferencesName, Context.MODE_PRIVATE);
        return new Gson().fromJson(pref.getString(Constants.USER,""),User.class);
    }


    public User getUser(FinalResultActivity context) {
        SharedPreferences pref = context.getSharedPreferences(sharedPreferencesName, Context.MODE_PRIVATE);
        return new Gson().fromJson(pref.getString(Constants.USER,""),User.class);
    }

    public User getUser(InfoFragment context) {
        SharedPreferences pref = context.getActivity().getSharedPreferences(sharedPreferencesName, Context.MODE_PRIVATE);
        return new Gson().fromJson(pref.getString(Constants.USER,""),User.class);
    }
    public User getUser(ChartFragment context) {
        SharedPreferences pref = context.getActivity().getSharedPreferences(sharedPreferencesName, Context.MODE_PRIVATE);
        return new Gson().fromJson(pref.getString(Constants.USER,""),User.class);
    }


    public void clearSharedPref(@NonNull Context context) {
        SharedPreferences pref = context.getSharedPreferences(sharedPreferencesName, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = pref.edit();
        editor.clear();
        editor.apply();
    }


}
