package com.example.copybara;

public class MyAdapter {
}
