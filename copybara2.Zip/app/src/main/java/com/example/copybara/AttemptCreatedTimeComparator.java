package com.example.copybara;

import com.example.copybara.data.Attempt;

import java.util.Comparator;

public class AttemptCreatedTimeComparator implements Comparator<Attempt> {

    @Override
    public int compare(Attempt attempt, Attempt t1) {
        return String.valueOf(t1.getCreatedTime()).compareTo(String.valueOf(attempt.getCreatedTime()));
    }
}
