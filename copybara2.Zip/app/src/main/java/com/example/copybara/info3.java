package com.example.copybara;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class info3 extends AppCompatActivity{
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.info3);

    }}