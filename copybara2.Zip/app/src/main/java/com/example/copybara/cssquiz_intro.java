package com.example.copybara;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;

import com.example.copybara.other.Constants;

public class cssquiz_intro extends AppCompatActivity{
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.cssquiz_intro);

        ImageButton python_quizstart = findViewById(R.id.quizstart);

        python_quizstart.setOnClickListener(view -> {
            Intent intent = new Intent(cssquiz_intro.this, pythonActivity.class);
            intent.putExtra(Constants.SUBJECT,getString(R.string.css));
            startActivity(intent);
        });

        findViewById(R.id.backarrow).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }}

